#!/bin/sh
dir=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd $dir;
export MERGED_LEF_UNPADDED='./tmp/merged_unpadded.lef';
export TRITONROUTE_RPT_PREFIX='./reports/routing/detailed';
export OR_SCRIPT_0='openlane/scripts/openroad/droute.tcl';
export CURRENT_GUIDE='./tmp/routing/22-global.guide';
export TRITONROUTE_FILE_PREFIX='./tmp/routing/detailed';
export SAVE_DEF='./out.def';
export RT_MAX_LAYER='met5';
export DRT_OPT_ITERS='64';
export CURRENT_DEF='./in.def';
export ROUTING_CORES='2';
export RT_MIN_LAYER='met1';
OPENROAD_BIN=${OPENROAD_BIN:-openroad}
$OPENROAD_BIN -exit $OR_SCRIPT_0
    